scaling = function(vettore){
  vettore.scalato = (vettore- mean(vettore))/sd(vettore)
  return(vettore.scalato)
}