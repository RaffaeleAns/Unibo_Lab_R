funz = function(){
  return(c(2,3))
}

funz